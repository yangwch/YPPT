export const FONTS = [
  '默认字体',
  '宋体',
  '黑体',
  '微软雅黑',
  '仿宋',
  '楷体',
  'Arial',
  'Droid Serif',
  'Source Code Pro'
]

export const FONT_SIZES = [
  12,
  14,
  16,
  18,
  20,
  24,
  28,
  32,
  36,
  40,
  50,
  60,
  70
]