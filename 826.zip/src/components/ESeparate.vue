<template>
  <div class="separate"></div>
</template>
<style scoped>
  .separate {
    display: inline-block;
    line-height: 100%;
    border-right: 1px solid #ccc;
    height: 18px;
    vertical-align: text-top;
    margin-left: 10px;
  }
</style>
